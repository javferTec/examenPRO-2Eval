package com.fpmislata.daw.prog.ejercicios.tema10.soluciones;

public enum HDType {
    HDD_NOR,
    HDD_NAND,
    SDD_25,
    SDD_M2
}
