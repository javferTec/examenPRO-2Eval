package com.fpmislata.ejercicio14_3.controller;

import org.springframework.stereotype.Controller;

@Controller
public class MainController {
    
    public String index() {
        return "index";
    }
}
