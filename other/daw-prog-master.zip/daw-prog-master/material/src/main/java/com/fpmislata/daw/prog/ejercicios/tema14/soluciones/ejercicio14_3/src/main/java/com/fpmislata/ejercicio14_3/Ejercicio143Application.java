package com.fpmislata.ejercicio14_3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ejercicio143Application {

	public static void main(String[] args) {
		SpringApplication.run(Ejercicio143Application.class, args);
	}

}
