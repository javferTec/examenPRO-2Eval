package com.fpmislata.daw.prog.ejercicios.tema13.soluciones.ejercicio4.exceptions;

public class ForeignKeyConstraintException extends Exception{

    public ForeignKeyConstraintException(String message) {
        super(message);
    }
    
}
