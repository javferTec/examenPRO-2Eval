package com.fpmislata.ejercicio14_3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ejercicio143ApplicationTests {

	@Test
	void contextLoads() {
	}

}
