package com.fpmislata.daw.prog.ejercicios.tema11.soluciones.front;

public class Menu {
    
    public static void show(){
        System.out.println("1.- Listado clientes");
        System.out.println("2.- Buscar cliente");
        System.out.println("0.- Salir");
        System.out.println("----------------------");
        System.out.print("Opción: ");
    }
}
