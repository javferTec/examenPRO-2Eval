package com.fpmislata.daw.prog.ejercicios.tema08_III.soluciones;

public class Ejercicio01 {
    
    public static void main(String[] args) {
        System.out.println(Calculadora01.sumar(10, 3));
        System.out.println(Calculadora01.restar(10, 3));
        System.out.println(Calculadora01.multiplicar(10, 3));
        System.out.println(Calculadora01.dividir(10, 3));
    }
}
