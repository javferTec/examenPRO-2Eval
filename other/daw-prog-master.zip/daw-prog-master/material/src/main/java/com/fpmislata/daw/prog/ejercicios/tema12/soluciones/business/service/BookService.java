package com.fpmislata.daw.prog.ejercicios.tema12.soluciones.business.service;

import java.util.List;

import com.fpmislata.daw.prog.ejercicios.tema12.soluciones.business.entity.Book;

public interface BookService {
    
    public List<Book> getAll();

}
