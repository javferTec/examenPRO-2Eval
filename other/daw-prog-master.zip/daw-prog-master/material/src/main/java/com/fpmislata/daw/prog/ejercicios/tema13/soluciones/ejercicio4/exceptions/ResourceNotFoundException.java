package com.fpmislata.daw.prog.ejercicios.tema13.soluciones.ejercicio4.exceptions;

public class ResourceNotFoundException extends Exception{

    public ResourceNotFoundException(String message) {
        super(message);
    }

}
