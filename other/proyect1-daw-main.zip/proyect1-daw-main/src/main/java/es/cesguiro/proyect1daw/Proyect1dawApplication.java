package es.cesguiro.proyect1daw;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Proyect1dawApplication {

	public static void main(String[] args) {
		SpringApplication.run(Proyect1dawApplication.class, args);
	}

}
